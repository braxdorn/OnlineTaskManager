package com.bjd.OnlineTaskManager;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class OnlineTaskManagerApplication {

	public static void main(String[] args) {
		SpringApplication.run(OnlineTaskManagerApplication.class, args);
	}

}
